package AE06;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;


import static com.mongodb.client.model.Filters.*;

import java.util.ArrayList;
import java.util.Scanner;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.json.JSONObject;

public class Principal {
	
	//Metodo para realizar la conexion a la base de datos en todos los metodos siguientes:
	//Devuelve la coleccion de la base de datos
	public MongoCollection<Document> colec(){
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("BIBLIOTECA");
		MongoCollection<Document> coleccion = database.getCollection("Libros");
		return coleccion;
	}
	
	//Metodo que muestra la lista completa de libros:
	public void listaLibros() {
		MongoCollection<Document> coleccion = colec();
		MongoCursor<Document> cursor = coleccion.find().iterator();		
		while(cursor.hasNext()) {
			//System.out.println(cursor.next().toJson());
		}
	}
	
	//Metodo que recibe por parametros el ID del libro que se quiere ver la informacion:
	public void mostrarLibro(String id) {
		MongoCollection<Document> coleccion = colec();
		MongoCursor<Document> cursor = coleccion.find().iterator();	
		Bson query = eq("Id", id);
		cursor = coleccion.find(query).iterator();
		while (cursor.hasNext()) {
			System.out.println(cursor.next().toJson());
		}
		
	}
	
	
	//Metodo que recibe por parametros los datos del libro que se quiere crear:
	public void crearLibro(String ID, String titulo, String autor, String anyoNacimiento, String anyoPublicacion, String editorial, String numPaginas) {
		MongoCollection<Document> coleccion = colec();
		Document doc = new Document();
		doc.append("Id", ID);
		doc.append("Titol", titulo);
		doc.append("Autor", autor);
		doc.append("Any_naixement", anyoNacimiento);
		doc.append("Any_publicacio", anyoPublicacion);
		doc.append("Editorial", editorial);
		doc.append("Nombre_pagines", numPaginas);
		coleccion.insertOne(doc);
	}
	
	
	//Metodo que recibe por parametros el ID del libro que se quiere modificar:
	public void modificarLibro(String id) {
		MongoCollection<Document> coleccion = colec();
		Scanner teclado2 = new Scanner(System.in);
		Document findDocument = new Document("ID", id);
		System.out.print("Titulo: ");
		String titulo = teclado2.nextLine();
		System.out.print("Autor: ");
		String autor = teclado2.nextLine();
		System.out.print("Anyo nacimiento: ");
		String anyoNacimiento = teclado2.nextLine();
		System.out.print("Anyo publicacion: ");
		String anyoPublicacion = teclado2.nextLine();
		System.out.print("Editorial: ");
		String editorial = teclado2.nextLine();
		System.out.print("Numero paginas: ");
		String numPaginas = teclado2.nextLine();
		
		BasicDBObject actualizarTitulo = new BasicDBObject();
		actualizarTitulo.append("$set", new BasicDBObject().append("Titol", titulo));
		
		BasicDBObject actualizarAutor = new BasicDBObject();
		actualizarAutor.append("$set", new BasicDBObject().append("Autor", autor));
		
		BasicDBObject actualizarANacimiento = new BasicDBObject();
		actualizarANacimiento.append("$set", new BasicDBObject().append("Any_naixement", anyoNacimiento));
		
		BasicDBObject actualizarAPublicacion = new BasicDBObject();
		actualizarAPublicacion.append("$set", new BasicDBObject().append("Any_publicacio", anyoPublicacion));
		
		BasicDBObject actualizarEditorial = new BasicDBObject();
		actualizarEditorial.append("$set", new BasicDBObject().append("Editorial", editorial));
		
		BasicDBObject actualizarNPaginas = new BasicDBObject();
		actualizarNPaginas.append("$set", new BasicDBObject().append("Nombre_pagines", numPaginas));
		
		BasicDBObject BuscarID = new BasicDBObject();
		BuscarID.append("Id", id);
		
		coleccion.updateOne(BuscarID, actualizarTitulo);
		coleccion.updateOne(BuscarID, actualizarAutor);
		coleccion.updateOne(BuscarID, actualizarANacimiento);
		coleccion.updateOne(BuscarID, actualizarAPublicacion);
		coleccion.updateOne(BuscarID, actualizarEditorial);
		coleccion.updateOne(BuscarID, actualizarNPaginas);
		
	}
	
	
	//Metodo que recibe por parametros el ID del libro que se quiere borrar:
	public void borrarLibro(String id) {
		MongoCollection<Document> coleccion = colec();
		System.out.println("Tamanyo coleccion " + coleccion.count());
		coleccion.deleteOne(eq("Id", id));
		System.out.println("Tamanyo coleccion " + coleccion.count());
	}
	
	public static void main(String[] args) {
		boolean menu = false;
		Principal prin = new Principal();
		Scanner teclado = new Scanner(System.in);
		
		while(!menu){
			System.out.println("----MENU----");
			System.out.println("1. Mostrar todos los titulos de la biblioteca:");
			System.out.println("2. Mostrar la informacion detallada de un libro a partir de su id:");
			System.out.println("3. Anyadir un nuevo libro a la biblioteca:");
			System.out.println("4. Modificar atributos de un libro a partir de su id:");
			System.out.println("5. Borrar un libro a partir de su id:");
			System.out.println("6. Salir.");
			System.out.print("Elige una de las anteriores opciones: ");
			int seleccion = teclado.nextInt();
		
		switch (seleccion) {
		case 1:
			prin.listaLibros();
			break;
		case 2:
			System.out.print("Escribe la id:");
			int identificador = teclado.nextInt();
			String pasar = identificador+"";
			prin.mostrarLibro(pasar);
			break;
		case 3:
			Scanner tecladoExtra = new Scanner(System.in);
			System.out.print("Id: ");
			String ID = tecladoExtra.nextLine();
			System.out.print("Titulo: ");
			String titulo = tecladoExtra.nextLine();
			System.out.print("Autor: ");
			String autor = tecladoExtra.nextLine();
			System.out.print("Anyo nacimiento: ");
			String anyoNacimiento = tecladoExtra.nextLine();
			System.out.print("Anyo publicacion: ");
			String anyoPublicacion = tecladoExtra.nextLine();
			System.out.print("Editorial: ");
			String editorial = tecladoExtra.nextLine();
			System.out.print("Numero paginas: ");
			String numPaginas = tecladoExtra.nextLine();
			
			prin.crearLibro(ID, titulo, autor, anyoNacimiento, anyoPublicacion, editorial, numPaginas);
			break;
		case 4:
			System.out.print("ID del libro a modificar: ");
			int ident = teclado.nextInt();
			String paso = ident+"";
			prin.modificarLibro(paso);
			break;
		case 5:
			System.out.print("ID del libro que queire borrar: ");
			int idLibroBorrar = teclado.nextInt();
			String pasador = idLibroBorrar+"";
			prin.mostrarLibro(pasador);
			prin.borrarLibro(pasador);
			System.out.println("Libro borrado.");
			break;
		case 6:
			menu = true;
			
			break;
			
	}
	}
	}	
}
