package libros;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class libros {
	public static void main(String[] args) throws IOException, ClassNotFoundException {

		Class.forName("com.mysql.cj.jdbc.Driver");

		int batchSize = 20;

		Connection connection = null;

		try {

			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/libros", "root", "");
			connection.setAutoCommit(false);

			PreparedStatement statement = connection.prepareStatement(
					"INSERT INTO libros (titulo, autor, anyoNacimiento, anyoPublicacion, editorial, numPaginas) VALUES (?, ?, ?, ?, ?, ?)");

			BufferedReader lineReader = new BufferedReader(new FileReader("AE04_T1_4_JDBC_Datos.csv"));
			String lineText = null;

			int count = 0;

			lineReader.readLine(); // SALTAR PRIMERA LINEA

			while ((lineText = lineReader.readLine()) != null) {
				String[] data = lineText.split(";");
				String titulo = data[0];
				String autor = data[1];
				String anyoNacimiento = data[2];
				String anyoPublicacion = data[3];
				String editorial = data[4];
				String numPaginas = data[5];

				statement.setString(1, titulo);
				statement.setString(2, autor);

				statement.setString(3, anyoNacimiento);

				statement.setString(4, anyoPublicacion);

				statement.setString(5, editorial);

				statement.setString(6, numPaginas);

				statement.addBatch();

				if (count % batchSize == 0) {
					statement.executeBatch();
				}
			}

			lineReader.close();

			// EJECUTAR EL PRIMER CODIGO, ENCARGADO DE MIGRAR LA INFORMACION:
			statement.executeBatch();

			Statement stmt = connection.createStatement();
			ResultSet rs = stmt
					.executeQuery("SELECT titulo, autor, anyoNacimiento FROM libros WHERE anyoNacimiento < '1950'");
			// EJECUTA EL SEGUNDO CODIGO, ENCARGADO DE BUSCAR LOS AUTORES ESPECIFICADOS:
			statement.executeBatch();
			System.out.println("Libros donde el autor nacio antes del 1950: ");
			while (rs.next()) {
				System.out.println(rs.getString(1) + "======" + rs.getString(2) + "======" + rs.getString(3) + "\n");
			}

			rs = stmt.executeQuery("SELECT editorial, anyoPublicacion FROM libros WHERE anyoPublicacion > '2000'");
			// EJECUTA EL TERCER CODIGO, ENCARGADO DE BUSCAR LAS EDITORIALES ESPECIFICADAS:
			statement.executeBatch();
			System.out.println("Editoriales que han publicado un libro en el siglo XXI: ");
			while (rs.next()) {
				System.out.println(rs.getString(1) + "======" + rs.getString(2) + "\n");
			}

			rs.close();

			connection.commit();
			connection.close();

		} catch (IOException ex) {
			System.err.println(ex);
		} catch (SQLException ex) {
			ex.printStackTrace();

			try {
				connection.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
